<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CuentaMaquetador
 *
 * @author Josué Francisco
 */
class CuentaMaquetador implements GenericMaquetador {

    public function maquetaArrayObject(array $entidades) {
        
    }

    public function maquetaObject(EntityDTO $entidad) {
        
    }
    public function maquetaFormCuentaConfig(UsuarioDTO $user, CuentaDTO $cuenta){
        
    }

}
