<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class CarritoComprasMaquetador implements GenericMaquetador {

    public function maquetaArrayObject(array $entidades) {
        return NULL;
    }
    
    //Este metodo para mostrar la ficha tecnica de un producto
    public function maquetaObject(EntityDTO $entidad) {
        $entidad instanceof CarritoComprasDTO;
    }

    public function maquetaCarritoInModal(CarritoComprasDTO $carrito) {
        $botones = FALSE;
        $modal = new ModalSimple();
        $items = $carrito->getItems();
        $totalCarrito = Validador::formatPesos($carrito->getTotal());
        $impuestosCarrito = Validador::formatPesos($carrito->getImpuestos());
        $subTotalCarrito = Validador::formatPesos($carrito->getSubtotal());
        
        $modal->open();
        if (empty($items)) {
            $vacio = new Neutral();
            $vacio->setValor("No has agregado productos al carrito ;)");
            $modal->addElemento($vacio);
        } else {
            $botones = TRUE;
            echo('<div class="w3-card-8">
                <div class="w3-row w3-theme-d1">
                    <div class="w3-container w3-threequarter">
                        <span class="w3-large w3-text-orange">Esto es lo que deseas comprar</span>
                    </div>
                    <div class="w3-container w3-quarter"><img src="../media/img/carrito.png" style="width: 30%; height: auto;"></div>
                </div>
                <table class="w3-table-all w3-tiny">
                    <tr>
                        <th>PRODUCTO</th>
                        <th>PRECIO U.</th>
                        <th>CANTIDAD</th>
                        <th>TOTAL</th>
                        <th>VER PRODUCTO</th>
                    </tr>');
            foreach ($items as $it) {
                $it instanceof ItemCarritoDTO;
                $pro = $it->getProducto();
                $pro instanceof ProductoDTO;
                $precioU = Validador::formatPesos($pro->getPrecio());
                $idProducto = CriptManager::urlVarEncript($it->getProductoIdProducto());
                $cantidad = $it->getCantidad();
                $total = Validador::formatPesos($it->getCostoTotal());
                $prodName = ($pro->getNombre());

                echo('<tr>
                <td>' . $prodName . '</td>
                <td>' . $precioU . '</td>
                <td>' . $cantidad . '</td>
                <td>' . $total . '</td>
                <td><a href="producto_ficha_tecnica.php?producto_id='.$idProducto.'"><button class="m-boton-a w3-tiny">Ver Producto</button></a></td>
             </tr>');
            }
            if($botones){
                echo('<tr><td colspan=5><span class="w3-tiny"><b>SUBTOTAL</b> = '.$subTotalCarrito.'</span><span class="w3-tiny"><br><b>IMPUESTOS</b> = '.$impuestosCarrito.'</span>
                     <br><span class="w3-tiny"><b>TOTAL</b> = '.$totalCarrito.'</span></td></tr>');
            }
        }
        echo('</table>');
        if($botones){
            echo('<div class="w3-center w3-padding-8">
                <a href="gestion_carrito.php"><button class="w3-btn w3-yellow w3-round-large w3-hover-blue">Administrar Carrito</button></a>
                <a href="comprar_productos.php"><button class="w3-btn w3-theme-d5 w3-round-large w3-hover-green">Realizar Compra</button></a>
            </div>');
        }
        echo('</div>');
        $closeBtn = new CloseBtn();
        $closeBtn->setValor("Cerrar");
        $modal->addElemento($closeBtn);
        $modal->maquetar();
        $modal->close();
    }

}
