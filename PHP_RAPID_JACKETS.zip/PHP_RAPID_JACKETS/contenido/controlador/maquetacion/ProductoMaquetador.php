<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ProductoMaquetador
 *
 * @author Josué Francisco
 */
class ProductoMaquetador implements GenericMaquetador {

    public function maquetaArrayObject(array $entidades) {
        echo('<div class="w3-row" id="productos_principal">');
        foreach ($entidades as $producto) {
            $producto instanceof ProductoDTO;
            $nombre = $producto->getNombre();
            $precio = Validador::formatPesos($producto->getPrecio());
            $idProducto = base64_encode($producto->getIdProducto());
            $idProductoUrl = CriptManager::urlVarEncript($producto->getIdProducto());
            $foto = $this->urlFoto($producto->getFoto());
            $cantidad = $producto->getCantidad();
            echo('<div class="w3-col m4 l2 s10">
                        <div class="w3-card-8 w3-white m-producto-card">
                            <a href="producto_ficha_tecnica.php?producto_id='.$idProductoUrl.'"><img src="' . $foto . '" alt="' . $nombre . '" title="' . $nombre . '" class="m-producto-view-1-img"></a>
                            <input type="hidden" value="' . $idProducto . '">
                            <div class="w3-container w3-white m-producto-name">
                                <span>' . $nombre . '</span>                                
                            </div>
                            <div class="w3-row w3-theme-d1">
                                <div class="w3-half w3-center">
                                    <span class="w3-badge w3-black w3-padding-4">' . $precio . '</span>
                                </div>
                                <div class="w3-half w3-center">
                                    <button class="m-boton-add-carrito" onclick="agregarAlCarrito(this)">
                                        <input type="hidden" value="' . $idProducto . '">
                                        <img src="../media/img/carrito_compra.png" alt="Agregar al carrito" title="Agregar al carrito" class="m-carrito">
                                        Agregar al carrito
                                    </button>
                                </div>
                                <div class="w3-center"><input type="number" id="' . $idProducto . '" class="input_carrito w3-center" max="' . $cantidad . '" min="1" placeholder="Cantidad"></div>
                            </div>
                        </div>
                    </div>');
        }
        echo('</div>');
    }

    public function urlFoto($foto) {
        if ($foto == "SIN_ASIGNAR") {
            return "../media/img/default_foto.png";
        } else {
            return $foto;
        }
    }

    public function maquetaCategoriasForUser() {
        $categoriaDAO = new CategoriaDAO();
        $categorias = $categoriaDAO->findAll();
        echo('<select name="categoria_id" id="categoria_id" class="m-selects" onchange="findByCategoria(this);">');
        foreach ($categorias as $cat) {
            $cat instanceof CategoriaDTO;
            $idCat = $cat->getIdCategoria();
            $nombre = Validador::fixTexto($cat->getNombre());
            if ($cat->getActiva() && $cat->getIdCategoria() !== $cat->getCategoriaIdCategoria()) {
                echo('<option value="' . $idCat . '">' . $nombre . '</option>');
            }
        }
        echo('</select>');
    }

    public function maquetaObject(EntityDTO $entidad) {
        //Meto para mostrar un producto en su modod de ficha Tecnica
        $entidad instanceof ProductoDTO;
        $categoriaDAO = CategoriaDAO::getInstancia();
        $categoriaDAO instanceof CategoriaDAO;
        $catFind = new CategoriaDTO();
        $catFind->setIdCategoria($entidad->getCategoriaIdCategoria());
        $cateDTO = $categoriaDAO->find($catFind);

        $idProducto = $entidad->getIdProducto();
        $categoriaNombre = $cateDTO->getNombre();
        $nombre = $entidad->getNombre();
        $precio = Validador::formatPesos($entidad->getPrecio());
        $descripcion = $entidad->getDescripcion();
        $cantidadDisponible = $entidad->getCantidad();
        $urlFoto = $this->urlFoto($entidad->getFoto());


        echo('<div id="' . $idProducto . '" class="w3-container w3-theme-l5">
                <div class="w3-row">
                    <div class="w3-quarter w3-card-4">
                        <img class="m-producto-mq-image" src="' . $urlFoto . '" alt="' . $nombre . '" title="' . $nombre . '">
                    </div>
                    <div class="w3-threequarter w3-container w3-card-4">
                        <div class=" m-producto-big-name">' . $nombre . '</div><br>
                        <span class="m-tituloA">Categoria : <b>' . $categoriaNombre . '</b></span>
                        <div class="w3-row">
                            <div class="w3-half w3-container w3-card-4 w3-center">
                                <span class="w3-tag w3-theme-d5 w3-large">Precio</span>
                                <span class="w3-badge w3-light-green w3-large w3-padding-12">' . $precio . '</span>
                            </div>
                            <div class="w3-half w3-container w3-card-4 w3-center">
                                <span class="w3-badge w3-light-green w3-large w3-padding-12">' . $cantidadDisponible . '</span>
                                <span class="w3-tag w3-theme-d5 w3-large">Unidades Disponibles</span>
                            </div>
                        </div>
                        <p class="w3-justify w3-theme-light w3-large">
                            ' . $descripcion . '
                        </p>
                    </div>
                </div>
            </div>');
    }

//put your code here
}
